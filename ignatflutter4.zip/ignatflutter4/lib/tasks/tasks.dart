import 'package:flutter/material.dart';

class TasksScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Tasks Screen',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
