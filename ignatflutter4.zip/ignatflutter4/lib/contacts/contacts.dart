import 'package:flutter/material.dart';

class ContactsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Contacts Screen',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
