import 'package:flutter/material.dart';

class NotesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Notes Screen',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
